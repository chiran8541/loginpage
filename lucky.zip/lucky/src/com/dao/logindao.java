package com.dao;

public interface logindao {
	public String authenticate(String username, String password);
}
